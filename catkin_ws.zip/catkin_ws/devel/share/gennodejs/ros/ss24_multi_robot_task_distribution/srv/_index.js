
"use strict";

let TaskService = require('./TaskService.js')

module.exports = {
  TaskService: TaskService,
};
