// Auto-generated. Do not edit!

// (in-package ss24_multi_robot_task_distribution.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let TaskRequest = require('../msg/TaskRequest.js');

//-----------------------------------------------------------

let TaskResponse = require('../msg/TaskResponse.js');

//-----------------------------------------------------------

class TaskServiceRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.request = null;
    }
    else {
      if (initObj.hasOwnProperty('request')) {
        this.request = initObj.request
      }
      else {
        this.request = new TaskRequest();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TaskServiceRequest
    // Serialize message field [request]
    bufferOffset = TaskRequest.serialize(obj.request, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TaskServiceRequest
    let len;
    let data = new TaskServiceRequest(null);
    // Deserialize message field [request]
    data.request = TaskRequest.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'ss24_multi_robot_task_distribution/TaskServiceRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'ccd9b9b3bb0c3b2844a1c63447a3591c';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # TaskService.srv
    TaskRequest request
    
    ================================================================================
    MSG: ss24_multi_robot_task_distribution/TaskRequest
    int32 robot_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TaskServiceRequest(null);
    if (msg.request !== undefined) {
      resolved.request = TaskRequest.Resolve(msg.request)
    }
    else {
      resolved.request = new TaskRequest()
    }

    return resolved;
    }
};

class TaskServiceResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.response = null;
    }
    else {
      if (initObj.hasOwnProperty('response')) {
        this.response = initObj.response
      }
      else {
        this.response = new TaskResponse();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TaskServiceResponse
    // Serialize message field [response]
    bufferOffset = TaskResponse.serialize(obj.response, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TaskServiceResponse
    let len;
    let data = new TaskServiceResponse(null);
    // Deserialize message field [response]
    data.response = TaskResponse.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += TaskResponse.getMessageSize(object.response);
    return length;
  }

  static datatype() {
    // Returns string type for a service object
    return 'ss24_multi_robot_task_distribution/TaskServiceResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '84d1176581ad2244fe4224fe4d3cb946';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    TaskResponse response
    
    
    
    ================================================================================
    MSG: ss24_multi_robot_task_distribution/TaskResponse
    int32 client_id
    string[] shelves
    int32[] item_quantities
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TaskServiceResponse(null);
    if (msg.response !== undefined) {
      resolved.response = TaskResponse.Resolve(msg.response)
    }
    else {
      resolved.response = new TaskResponse()
    }

    return resolved;
    }
};

module.exports = {
  Request: TaskServiceRequest,
  Response: TaskServiceResponse,
  md5sum() { return 'a3bf21f1df4f1c011d3f98e27607fec1'; },
  datatype() { return 'ss24_multi_robot_task_distribution/TaskService'; }
};
