
"use strict";

let ShelfGoalPose = require('./ShelfGoalPose.js');
let TaskResponse = require('./TaskResponse.js');
let TaskRequest = require('./TaskRequest.js');

module.exports = {
  ShelfGoalPose: ShelfGoalPose,
  TaskResponse: TaskResponse,
  TaskRequest: TaskRequest,
};
