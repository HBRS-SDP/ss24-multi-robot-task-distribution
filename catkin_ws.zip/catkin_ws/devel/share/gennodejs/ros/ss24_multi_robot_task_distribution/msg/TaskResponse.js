// Auto-generated. Do not edit!

// (in-package ss24_multi_robot_task_distribution.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class TaskResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.client_id = null;
      this.shelves = null;
      this.item_quantities = null;
    }
    else {
      if (initObj.hasOwnProperty('client_id')) {
        this.client_id = initObj.client_id
      }
      else {
        this.client_id = 0;
      }
      if (initObj.hasOwnProperty('shelves')) {
        this.shelves = initObj.shelves
      }
      else {
        this.shelves = [];
      }
      if (initObj.hasOwnProperty('item_quantities')) {
        this.item_quantities = initObj.item_quantities
      }
      else {
        this.item_quantities = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TaskResponse
    // Serialize message field [client_id]
    bufferOffset = _serializer.int32(obj.client_id, buffer, bufferOffset);
    // Serialize message field [shelves]
    bufferOffset = _arraySerializer.string(obj.shelves, buffer, bufferOffset, null);
    // Serialize message field [item_quantities]
    bufferOffset = _arraySerializer.int32(obj.item_quantities, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TaskResponse
    let len;
    let data = new TaskResponse(null);
    // Deserialize message field [client_id]
    data.client_id = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [shelves]
    data.shelves = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [item_quantities]
    data.item_quantities = _arrayDeserializer.int32(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.shelves.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    length += 4 * object.item_quantities.length;
    return length + 12;
  }

  static datatype() {
    // Returns string type for a message object
    return 'ss24_multi_robot_task_distribution/TaskResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'fc0c46716e77677f20ccaa3752057b50';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int32 client_id
    string[] shelves
    int32[] item_quantities
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TaskResponse(null);
    if (msg.client_id !== undefined) {
      resolved.client_id = msg.client_id;
    }
    else {
      resolved.client_id = 0
    }

    if (msg.shelves !== undefined) {
      resolved.shelves = msg.shelves;
    }
    else {
      resolved.shelves = []
    }

    if (msg.item_quantities !== undefined) {
      resolved.item_quantities = msg.item_quantities;
    }
    else {
      resolved.item_quantities = []
    }

    return resolved;
    }
};

module.exports = TaskResponse;
